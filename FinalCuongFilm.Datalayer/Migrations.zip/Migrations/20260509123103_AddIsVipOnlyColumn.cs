﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinalCuongFilm.Datalayer.Migrations
{
    /// <inheritdoc />
    public partial class AddIsVipOnlyColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.CreateIndex(
            //    name: "IX_UserSubscriptions_PackageId",
            //    table: "UserSubscriptions",
            //    column: "PackageId");

            //migrationBuilder.AddForeignKey(
            //    name: "FK_UserSubscriptions_VipPackages_PackageId",
            //    table: "UserSubscriptions",
            //    column: "PackageId",
            //    principalTable: "VipPackages",
            //    principalColumn: "Id",
            //    onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserSubscriptions_VipPackages_PackageId",
                table: "UserSubscriptions");

            migrationBuilder.DropIndex(
                name: "IX_UserSubscriptions_PackageId",
                table: "UserSubscriptions");
        }
    }
}
