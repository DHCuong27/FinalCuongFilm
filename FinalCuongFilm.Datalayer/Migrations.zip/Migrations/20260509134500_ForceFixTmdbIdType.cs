﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FinalCuongFilm.Datalayer.Migrations
{
    /// <inheritdoc />
    public partial class ForceFixTmdbIdType : Migration
    {
		/// <inheritdoc />
		protected override void Up(MigrationBuilder migrationBuilder)
		{
			// 1. Dùng lệnh SQL rà soát và xóa sạch các cột/index lỗi cũ trên Azure
			migrationBuilder.Sql(@"
        -- Bảng Movies: Xóa Index cũ nếu có
        IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_Movies_TmdbId_Long' AND object_id = OBJECT_ID('Movies'))
            DROP INDEX IX_Movies_TmdbId_Long ON Movies;
        IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_Movies_TmdbId' AND object_id = OBJECT_ID('Movies'))
            DROP INDEX IX_Movies_TmdbId ON Movies;

        -- Bảng Movies: Xóa cột Guid cũ
        IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'TmdbId' AND Object_ID = Object_ID(N'Movies'))
            ALTER TABLE Movies DROP COLUMN TmdbId;
        IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'TmdbId_Long' AND Object_ID = Object_ID(N'Movies'))
            ALTER TABLE Movies DROP COLUMN TmdbId_Long;

        -- Bảng Movies: Tạo lại cột TmdbId với chuẩn số nguyên (bigint)
        ALTER TABLE Movies ADD TmdbId bigint NULL;

        -- Bảng Actors: Xóa Index cũ nếu có
        IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_Actors_TmdbId_Long' AND object_id = OBJECT_ID('Actors'))
            DROP INDEX IX_Actors_TmdbId_Long ON Actors;
        IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'IX_Actors_TmdbId' AND object_id = OBJECT_ID('Actors'))
            DROP INDEX IX_Actors_TmdbId ON Actors;

        -- Bảng Actors: Xóa cột Guid cũ
        IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'TmdbId' AND Object_ID = Object_ID(N'Actors'))
            ALTER TABLE Actors DROP COLUMN TmdbId;
        IF EXISTS(SELECT * FROM sys.columns WHERE Name = N'TmdbId_Long' AND Object_ID = Object_ID(N'Actors'))
            ALTER TABLE Actors DROP COLUMN TmdbId_Long;

        -- Bảng Actors: Tạo lại cột chuẩn bigint
        ALTER TABLE Actors ADD TmdbId bigint NULL;
    ");

			// 2. Yêu cầu Entity Framework tạo lại Index xịn cho 2 cột mới
			migrationBuilder.CreateIndex(
				name: "IX_Movies_TmdbId",
				table: "Movies",
				column: "TmdbId",
				unique: true,
				filter: "[TmdbId] IS NOT NULL");

			migrationBuilder.CreateIndex(
				name: "IX_Actors_TmdbId",
				table: "Actors",
				column: "TmdbId",
				unique: true,
				filter: "[TmdbId] IS NOT NULL");
		}

		/// <inheritdoc />
		protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
